## ----"knitr-options", echo = FALSE--------------------------------------------
library(knitr)
opts_chunk$set(fig.height = 4.5,
               fig.align = "center",
               cache = FALSE,
               message = FALSE,
               warning = FALSE)

## ----"sessionInfo", echo = TRUE-----------------------------------------------
cat(paste(Sys.time(), Sys.timezone(), "\n"))
sessionInfo()

