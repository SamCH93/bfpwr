# bfpwr

**bfpwr** is an R package for power and sample size calculations for planned
Bayes factor analyses

## Installation

```r
## ## CRAN version (not yet available on CRAN)
## install.packages("bfpwr")

## from GitHub
## install.packages("remotes") # requires remotes package
remotes::install_github(repo = "SamCH93/bfpwr", subdir = "package")
```

## Usage

``` r
library("bfpwr")

## TODO add an example
``` 
