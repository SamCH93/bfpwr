bin2bf01. <- function(x1, n1, x2, n2, a0 = 1, b0 = 1, a1 = 1, b1 = 1, a2 = 1,
                      b2 = 1, log = FALSE) {
    ## input checks
    stopifnot(
        length(x1) == 1,
        is.numeric(x1),
        is.finite(x1),
        0 <= x1,

        length(n1) == 1,
        is.numeric(n1),
        is.finite(n1),
        0 < n1,
        x1 <= n1,

        length(x2) == 1,
        is.numeric(x2),
        is.finite(x2),
        0 <= x2,

        length(n2) == 1,
        is.numeric(n2),
        is.finite(n2),
        0 < n2,
        x2 <= n2,

        length(a0) == 1,
        is.numeric(a0),
        is.finite(a0),
        0 < a0,

        length(b0) == 1,
        is.numeric(b0),
        is.finite(b0),
        0 < b0,

        length(a1) == 1,
        is.numeric(a1),
        is.finite(a1),
        0 < a1,

        length(b1) == 1,
        is.numeric(b1),
        is.finite(b1),
        0 < b1,

        length(a2) == 1,
        is.numeric(a2),
        is.finite(a2),
        0 < a2,

        length(b2) == 1,
        is.numeric(b2),
        is.finite(b2),
        0 < b2,

        length(log) == 1,
        is.logical(log),
        !is.na(log)
    )

    logbf <-
        lbeta(x1 + x2 + a0, n1 + n2 - x1 - x2 + b0) -
        lbeta(x1 + a1, n1 - x1 + b1) -
        lbeta(x2 + a2, n2 - x2 + b2) +
        lbeta(a1, b1) +
        lbeta(a2, b2) -
        lbeta(a0, b0)

    if (log == TRUE) {
        return(logbf)
    } else {
        return(exp(logbf))
    }
}

#' @noRd
#' @title Two Group Binomial-Beta Bayes factor
#'
#' @description This function computes the Bayes factor for testing whether or
#'     not two binomial proportions are equal based on \eqn{x_1}{x1} and
#'     \eqn{x_2}{x2} observed successes out of \eqn{n_1}{n1} and \eqn{n_2}{n2}
#'     trials, respectively.
#'
#' Specifically, the Bayes factor quantifies the evidence for \eqn{H_0 \colon
#'     p_1 = p_2 = p}{H0: p1 = p2 = p} against \eqn{H_1 \colon p_1 \neq p_2}{H1:
#'     p1 != p2}. A beta prior is assigned to the common proportion \eqn{p}
#'     under the null hypothesis \eqn{H_0}{H0}, while under two independent beta
#'     priors are assigned to the proportions \eqn{p_1}{p1} and \eqn{p_2}{p2}.
#'
#' @md
#'
#' @param x1 Number of successes in group 1
#' @param n1 Number of trials in group 1
#' @param x2 Number of successes in group 2
#' @param n2 Number of trials in group 2
#' @param a0 Number of successes parameter of the beta prior distribution for
#'     common probability under the null hypothesis. Defaults to \code{1}
#' @param b0 Number of failures parameter of the beta prior distribution for
#'     common probability under the null hypothesis. Defaults to \code{1}
#' @param a1 Number of successes parameter of the beta prior distribution for
#'     probability in group 1 under the alternative hypothesis. Defaults to
#'     \code{1}
#' @param b1 Number of failures parameter of the beta prior distribution for
#'     probability in group 1 under the alternative hypothesis. Defaults to
#'     \code{1}
#' @param a2 Number of successes parameter of the beta prior distribution for
#'     probability in group 2 under the alternative hypothesis. Defaults to
#'     \code{1}
#' @param b2 Number of failures parameter of the beta prior distribution for
#'     probability in group 2 under the alternative hypothesis. Defaults to
#'     \code{1}
#' @param log Logical indicating whether the natural logarithm of the Bayes
#'     factor should be returned. Defaults to \code{FALSE}
#'
#' @inherit bf01 return
#'
#' @author Samuel Pawel
#'
#' @examples
#' ## example from Dablander et al. (2021, <https://doi.org/10.1002/sim.9278>)
#' #bin2bf01(x1 = 15, n1 = 493, x2 = 13, n2 = 488)
#'
#' #@export
bin2bf01 <- Vectorize(FUN = bin2bf01.)
